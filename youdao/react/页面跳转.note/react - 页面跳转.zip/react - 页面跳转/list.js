import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';
import "./css/list.css";
import {TimeHelper} from "../../../system/helper";
import {YBGParamsUrl} from "../base/yibangong";

class ListApp extends Component {
    constructor(pro) {
        super(pro);
        this.state = {
            height: `200px`
        }
    };

    render() {
        return (
            <div>
                <div className="total">
                    <span>最近一个月总数：</span>{this.props.pushListCount}
                </div>
                <div className="listData">
                    <table>
                        <thead className="fixedThead">
                        <tr>
                            <td className="tdWidth">行号</td>
                            <td className="tdWidth">最近预警时间</td>
                            <td className="tdWidth">应用组</td>
                            <td className="tdWidth">问题概要</td>
                            <td className="tdWidth">状态</td>
                            <td className="tdWidth">首次预警时间</td>
                        </tr>
                        </thead>
                        <tbody className="scrollTbody" height={this.state.height}>
                        {
                            this.props.pushListData &&
                            this.props.pushListData.map((item, key) => {
                                    item.state = this.getState(item.state);
                                    return (
                                        <tr key={key} onClick={this.jumpEventsPage.bind(this, item.ntfkey,item.time)}>
                                            <td className="tdWidth">{key + 1}</td>
                                            <td className="tdWidth">{TimeHelper.getTime(item.latestrecord_ts, 'FMS')}</td>
                                            <td className="tdWidth">{item.appgroup}</td>
                                            <td className="tdWidth">{item.title}</td>
                                            <td className="tdWidth">{item.state}</td>
                                            <td className="tdWidth">{TimeHelper.getTime(item.time, 'FMS')}</td>
                                        </tr>
                                    );
                                }
                            )
                        }
                        </tbody>
                    </table>
                </div>
            </div>
        );
    }

    getState = (num) => {
        if (num === 0) {
            return "新预警";
        } else if (num === 10) {
            return "报警持续中";
        } else if (num === 15) {
            return "已查看";
        } else if (num === 20) {
            return "已查看&报警持续中";
        } else if (num === 25) {
            return "已处理";
        } else {
            return num;
        }
    };

    jumpEventsPage = (ntfKey,time) => {
        /**
         * 跳转页面，并且当前此组件必须为export default withRouter(youComponent);不然拿不到props.history数据（直接url访问到此页面，需要提取props数据）
         *
         *  state: {ntfKey} :可以多个参数，目前是只有一个{XX,XXX,XXX}
         */
        this.props.history.push(
            {
                pathname: '/ybg/notifyRecordEvents',
                search: '?'+YBGParamsUrl,
                state: {ntfKey,time}
            }
         );
    };

    componentDidMount() {
        //第一次默认设置
        this.resize();
        //事件绑定,每次页面变化都设置
        window.addEventListener('resize', this.resize);
    };

    componentWillUnmount(){
        /**
         * 组件销毁之前，移除监听，避免内存溢出错误：
         *Warning: Can't perform a React state update on an unmounted component. This is a no-op, but it indicates a memory leak in your application. To fix, cancel all subscriptions and asynchronous tasks in the componentWillUnmount method.
         * 译意：组件已经不存在，依然还在操作 setState
         */
        window.removeEventListener('resize', this.resize);
    }
    resize = () => {
        /**
         * 自动设置列表内容高度，达到可以展示（内容小于高度）下拉滚动条的条件。
         * 页面高度减去上面的距离
         */
        const listScrollTbodyHeight = document.documentElement.clientHeight - 152;
        if (listScrollTbodyHeight > 200) {
            let newHeight = `${listScrollTbodyHeight}px`;
            this.setState({height: newHeight});
        }
    };
}

export default withRouter(ListApp);