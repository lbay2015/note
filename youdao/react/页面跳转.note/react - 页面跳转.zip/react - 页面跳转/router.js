import React,{ Component } from 'react';
import {BrowserRouter as Router,Route} from 'react-router-dom';
import {WelcomeApp} from '../pages/welcome/index';
import {YbgApp} from '../pages/yiBanGong/ybg/index';
import {NotifyRecordQueryApp} from '../pages/yiBanGong/notifyRecordQuery/index';
import {NotifyRecordEventsApp} from '../pages/yiBanGong/notifyRecordEvents/index';

/**
 * 路由设置:
 * 1、工程所有路径在此统一配置
 */
export class RouterApp extends Component {
    render() {
        return (
            <div>
                {/** basename是为了部署tomcat的时候，与工程名对应，
                 WelcomeApp :默认是访问的根路径/
                 不添加basename，WelcomeApp访问路径为: http://localhost:3000/
                 添加basename，WelcomeApp访问路径为：http://localhost:3000/mobile
                 **/}
                <Router basename="/mobile">
                    <Route exact path="/" component={WelcomeApp}/>
                    <Route exact path="/ybg" component={YbgApp}/>
                    <Route exact path="/ybg/notifyRecordQuery" component={NotifyRecordQueryApp}/>
                    <Route exact path="/ybg/notifyRecordEvents" component={NotifyRecordEventsApp}/>
                </Router>
            </div>
        );
    }
}
