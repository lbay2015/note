import React, { Component } from 'react';
import {YBGAjaxApp} from "../base/ybgajax";
import {HeaderApp} from "./header";
import {EventsApp} from "./events";

/**
 * 预警记录查询：单笔详情页
 */
export class NotifyRecordEventsApp extends Component {
    constructor(pro) {
        super(pro);
        this.state = {
            firstEvent:{},
            eventsCount: 0,
            eventList: [{}]
        }
    };

    render() {
        return (
            <div>
               <HeaderApp/>
               <EventsApp pushFirstEvent={this.state.firstEvent} pushEventList={this.state.eventList} pushEventsCount={this.state.eventsCount}/>
            </div>
        );
    };


    componentDidMount(){
        //页面默认加载
        this.setDescData();
    };


    setDescData = () => {
        let params = {
            "ntfkey": this.props.location.state.ntfKey,
            "time":this.props.location.state.time
        };

        YBGAjaxApp.getEvents(params,
            function (rs) {
                /**
                 * 数据渲染
                 */
                if(rs.code === 0){
                    this.setState({firstEvent:rs.result.first});
                    this.setState({eventsCount:rs.result.count});
                    this.setState({eventList:rs.result.datas});
                }else{
                    console.log(rs);
                }
            }.bind(this)
        );

    };


}
